using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using SMART_City.Models;

namespace SMART_City.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;

        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;
        }

        public void OnGet()
        {

        }

        public List<House> GetHouseUsage()
        {
            List<House> Houses = new List<House>();
            Houses.Add(new House("Kerkstraat", 10, "Berkel-Enschot", "Tilburg"));
            Houses.Add(new House("Koningsplein", 89, "Udenhout", "Tilburg"));
            Houses.Add(new House("Ringbaan-Noord", 166, "Tilburg", "Tilburg"));
            return Houses;
        }

        /*
        public List<Student> GetStudents()
        {
            List<Student> students = new List<Student>();
            students.Add(new Student("Bert", 42, "M"));
            students.Add(new Student("Ernie", 40, "M"));
            students.Add(new Student("Oscarin", 38, "F"));
            return students;
        }
        */
    }
}
