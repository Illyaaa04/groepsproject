using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SMART_City.Pages
{
    public class AboutUsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
