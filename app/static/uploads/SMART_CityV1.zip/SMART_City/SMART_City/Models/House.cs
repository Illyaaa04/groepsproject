﻿namespace SMART_City.Models
{
    public class House
    {
        public List<Sensor> Sensors { get; private set; } = new List<Sensor>();
        public double UsageHome { get; private set; }
        public string StreetName { get; private set; }
        public int HouseNumber { get; private set; }

        public string City { get; private set; }
        public string Municipality { get; private set; }


        public House(/*List<Sensor> sensors,*/ string streetName, int houseNumber, string city, string municipality)
        {
            //Sensors = sensors;
            StreetName = streetName;
            HouseNumber = houseNumber;
            City = city;
            Municipality = municipality;

            Random rnd = new Random();
            UsageHome = rnd.NextDouble() * 99 + 1;
        }

        public double CalculateTotalUsage() //Waarde uit List<Sensor> Sensors nog daadwerkelijk gebruiken
        {
            Random rnd = new Random();
            double TotalUsage = rnd.NextDouble() * 999 + 100;
            return TotalUsage;
        }
    }
}
