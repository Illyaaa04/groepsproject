﻿namespace SMART_City.Models
{
    public class Sensor
    {
        public string Name { get; private set; }
        public double Usage { get; private set; }

        public Sensor(string name, double usage)
        {
            Name = name;
            Usage = usage;
        }

        /*
        public void UpdateUsage()
        {
            return MethodeHelperAppDieMockDataGenereert();
        }
        */
    }
}
